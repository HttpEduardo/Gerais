/*
 * main.cpp / Sudoku_Solver
 *
 *  Created on: 09-Dec-2014
 *      Author: Gourav Siddhad
 */

#include "ss.h"
using namespace std;

int main()
{
	sudoku ori;
	ori.print();
	return 0;
}
